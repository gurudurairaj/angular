export const initialProductState = {
    allProducts: [],
    errorMessage: "",
    cart: []
}
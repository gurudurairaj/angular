/*
    define the reducer function here
*/ 
/*
    create the effects here to interact with the JSON server using products service
*/ 
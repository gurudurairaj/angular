export class Product {
    id: number;
    productName: string;
    productPrice: number;
    productImg: string;
    productBrand: string;
}